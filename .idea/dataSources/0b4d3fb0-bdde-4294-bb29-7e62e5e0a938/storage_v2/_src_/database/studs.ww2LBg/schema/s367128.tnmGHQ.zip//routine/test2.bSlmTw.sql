create function test2(pperson integer) returns character varying
    language plpgsql
as
$$
    declare
        answer varchar := 'u';
        person_id int;
        oobject_id int;
        characteristic_id int;
        place_id int;
        place_name varchar;
        kol int;
        i int;
    begin
        select count(*) into kol from actions;
        for i in 0..kol

        loop
        select person.id into person_id from person where person.id = pperson;
        select actions.characteristic_id into characteristic_id from actions where (actions.object_id = person_id or actions.subject_id = person_id) and
                                                                                   (i = actions.id);
        select characteristic.place_id into place_id from characteristic where characteristic.id =characteristic_id;
        select place.name into place_name from place where place.id = place_id;
        if place_name = 'лаборатория' then
            answer := 'да';
            return answer;
        end if;

        end loop ;
        answer := 'нет';
        return answer;

    end;
    $$;

alter function test2(integer) owner to s367128;

