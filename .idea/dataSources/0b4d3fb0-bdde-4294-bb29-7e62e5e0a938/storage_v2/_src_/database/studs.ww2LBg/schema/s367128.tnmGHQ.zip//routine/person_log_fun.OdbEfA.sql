create function person_log_fun() returns trigger
    language plpgsql
as
$$BEGIN
        Insert into person_log_table(time, type) values (current_date, tg_op);
        return new;
    end$$;

alter function person_log_fun() owner to s367128;

