create function test() returns integer
    language sql
as
$$
    select count(*) from person
    join actions on person.id = actions.object_id or person.id = actions.subject_id
    join association on person.group_id = association.id
    join characteristic on actions.characteristic_id = characteristic.id
    join place on characteristic.place_id = place.id
    where association.name = 'посторонние' and place.name = 'лаборатория';
$$;

alter function test() owner to s367128;

