create function test(ind integer) returns character varying
    language sql
as
$$
    select person.sname from person
    where person.id = ind;
$$;

alter function test(integer) owner to s367128;

